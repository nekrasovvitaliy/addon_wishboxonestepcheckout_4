<?php

defined('_JEXEC') or die;

echo $this->small_cart;
echo $this->_tmp_ext_html_previewfinish_start;
?>