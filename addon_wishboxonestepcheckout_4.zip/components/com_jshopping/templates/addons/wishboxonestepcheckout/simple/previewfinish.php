<?php
/**
* @package Joomla
* @subpackage JoomShopping
* @author Garry
* @website https://joom-shopping.com/
* @email info@joom-shopping.com
* @copyright Copyright © joom-shopping All rights reserved.
* @license GNU GPO
**/

defined('_JEXEC') or die;

echo $this->small_cart;
echo $this->_tmp_ext_html_previewfinish_start;
?>